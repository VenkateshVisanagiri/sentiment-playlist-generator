# Sentiment Playlist Generator

A tool that analyzes the sentiment of input text and generates a personalized playlist based on the detected mood.

## Features

- **Sentiment Analysis**: Analyzes text input to determine the overall sentiment (positive, negative, neutral) and specific emotion (joy, sadness, anger, etc.)
- **Playlist Generation**: Creates a customized playlist based on the detected emotion
- **User-friendly Interface**: Simple and intuitive web interface for entering text and viewing results
- **Responsive Design**: Works well on both desktop and mobile devices

## Technology Stack

- **Backend**:
  - Python
  - Flask (Web server)
  - NLTK (Natural Language Toolkit for sentiment analysis)
  - VADER (Valence Aware Dictionary and sEntiment Reasoner)

- **Frontend**:
  - HTML5
  - CSS3
  - JavaScript (ES6+)
  - Font Awesome (Icons)

## Prerequisites

- Python 3.6 or higher
- pip (Python package manager)

## Installation

1. Clone the repository or download the source code:

```bash
git clone https://github.com/yourusername/sentiment-playlist-generator.git
cd sentiment-playlist-generator
```

2. Install the required Python packages:

```bash
pip install flask flask-cors nltk
```

3. Download the required NLTK resources (this will happen automatically on first run, but you can do it manually):

```bash
python -c "import nltk; nltk.download('vader_lexicon'); nltk.download('punkt'); nltk.download('stopwords')"
```

## Usage

1. Start the application:

```bash
python main.py
```

2. Open your web browser and navigate to:

```
http://localhost:5000
```

3. Enter your text in the input field, select the number of songs you want in your playlist, and click "Analyze & Generate Playlist".

4. View your sentiment analysis results and personalized playlist.

## How It Works

1. **Text Input**: The user enters text describing their mood, thoughts, or feelings.

2. **Sentiment Analysis**: The backend analyzes the text using NLTK and VADER to determine:
   - Overall sentiment (positive, negative, neutral)
   - Specific emotion (joy, love, surprise, anger, sadness, fear, calm, energetic)
   - Sentiment scores (compound, positive, negative, neutral)

3. **Playlist Generation**: Based on the detected emotion, the system selects songs from a curated database that match the mood.

4. **Results Display**: The user is presented with their sentiment analysis results and a personalized playlist with links to listen to each song.

## Customization

### Adding Songs

You can add more songs to the database by:

1. Manually editing the `songs.json` file in the `src/backend/data` directory.

2. Using the API endpoint:

```
POST /api/songs
```

With the following JSON payload:

```json
{
    "emotion": "joy",
    "title": "Happy Song",
    "artist": "Artist Name",
    "url": "https://example.com/song"
}
```

## API Endpoints

The application provides the following API endpoints:

- `POST /api/analyze`: Analyze text sentiment and generate a playlist
- `GET /api/songs`: Get all songs in the database
- `POST /api/songs`: Add a new song to the database

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- NLTK and VADER for sentiment analysis capabilities
- Flask for the web framework
- All the artists whose songs are included in the playlists
