#!/bin/bash
echo "Starting Sentiment Playlist Generator..."
python3 run.py
