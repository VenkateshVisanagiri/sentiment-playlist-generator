/**
 * Sentiment Playlist Generator
 * Frontend JavaScript functionality
 */

document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const textInput = document.getElementById('text-input');
    const songCount = document.getElementById('song-count');
    const analyzeBtn = document.getElementById('analyze-btn');
    const resultsSection = document.getElementById('results-section');
    const loadingIndicator = document.getElementById('loading');
    const sentimentCategory = document.getElementById('sentiment-category');
    const emotionDetected = document.getElementById('emotion-detected');
    const sentimentScore = document.getElementById('sentiment-score');
    const playlistContainer = document.getElementById('playlist-container');

    // API URL (adjust as needed)
    const API_URL = 'http://localhost:5000/api';

    // Event Listeners
    analyzeBtn.addEventListener('click', analyzeSentiment);

    /**
     * Analyze text sentiment and generate playlist
     */
    async function analyzeSentiment() {
        const text = textInput.value.trim();
        const count = parseInt(songCount.value);

        // Validate input
        if (!text) {
            alert('Please enter some text to analyze.');
            return;
        }

        // Show loading indicator
        loadingIndicator.style.display = 'flex';
        resultsSection.style.display = 'none';

        try {
            // Send request to API
            const response = await fetch(`${API_URL}/analyze`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ text, count })
            });

            if (!response.ok) {
                throw new Error('Failed to analyze sentiment');
            }

            const data = await response.json();

            // Display results
            displayResults(data);

        } catch (error) {
            console.error('Error:', error);
            alert('An error occurred while analyzing the text. Please try again.');
        } finally {
            // Hide loading indicator
            loadingIndicator.style.display = 'none';
        }
    }

    /**
     * Display sentiment analysis and playlist results
     * @param {Object} data - Response data from API
     */
    function displayResults(data) {
        // Extract data
        const { sentiment, playlist } = data;

        // Display sentiment results
        sentimentCategory.textContent = capitalizeFirstLetter(sentiment.category);
        sentimentCategory.className = 'sentiment-value ' + sentiment.category;

        emotionDetected.textContent = capitalizeFirstLetter(sentiment.emotion);
        emotionDetected.className = 'sentiment-value ' + sentiment.emotion;

        sentimentScore.textContent = sentiment.scores.compound.toFixed(2);

        // Display playlist
        displayPlaylist(playlist);

        // Show results section
        resultsSection.style.display = 'flex';
    }

    /**
     * Display the generated playlist
     * @param {Array} playlist - Array of song objects
     */
    function displayPlaylist(playlist) {
        // Clear previous playlist
        playlistContainer.innerHTML = '';

        // Check if playlist is empty
        if (!playlist || playlist.length === 0) {
            playlistContainer.innerHTML = '<p>No songs found for this mood. Try a different text input.</p>';
            return;
        }

        // Create playlist items
        playlist.forEach((song, index) => {
            const playlistItem = document.createElement('div');
            playlistItem.className = 'playlist-item';

            playlistItem.innerHTML = `
                <div class="song-number">${index + 1}</div>
                <div class="song-info">
                    <div class="song-title">${song.title}</div>
                    <div class="song-artist">${song.artist}</div>
                </div>
                <div class="song-link">
                    <a href="${song.url}" target="_blank">Listen <i class="fas fa-external-link-alt"></i></a>
                </div>
            `;

            playlistContainer.appendChild(playlistItem);
        });
    }

    /**
     * Capitalize the first letter of a string
     * @param {string} string - String to capitalize
     * @returns {string} Capitalized string
     */
    function capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }
});
