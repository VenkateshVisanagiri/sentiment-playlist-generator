"""
Sentiment Playlist Generator API

This module provides a Flask API for analyzing text sentiment and generating
song playlists based on the detected emotion.
"""

from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import os
import sys
from pathlib import Path

# Add the parent directory to sys.path to import the modules
current_dir = Path(__file__).parent
if str(current_dir) not in sys.path:
    sys.path.append(str(current_dir))

from sentiment_analyzer import SentimentAnalyzer
from playlist_generator import PlaylistGenerator

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Initialize the sentiment analyzer and playlist generator
analyzer = SentimentAnalyzer()
playlist_generator = PlaylistGenerator()

@app.route('/')
def index():
    """Serve the main page."""
    return render_template('index.html')

@app.route('/api/analyze', methods=['POST'])
def analyze_text():
    """
    Analyze text sentiment and generate a playlist.
    
    Expects a JSON payload with a 'text' field.
    Returns sentiment analysis results and a playlist.
    """
    data = request.json
    
    if not data or 'text' not in data:
        return jsonify({'error': 'No text provided'}), 400
    
    text = data['text']
    count = data.get('count', 5)  # Default to 5 songs
    
    try:
        # Analyze sentiment
        sentiment_result = analyzer.analyze(text)
        
        # Generate playlist based on the detected emotion
        playlist = playlist_generator.generate_playlist(sentiment_result['emotion'], count)
        
        # Prepare response
        response = {
            'sentiment': sentiment_result,
            'playlist': playlist
        }
        
        return jsonify(response)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/songs', methods=['GET'])
def get_songs():
    """
    Get all songs in the database.
    
    Returns a dictionary of songs grouped by emotion.
    """
    try:
        return jsonify(playlist_generator.songs_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/songs', methods=['POST'])
def add_song():
    """
    Add a new song to the database.
    
    Expects a JSON payload with 'emotion', 'title', 'artist', and 'url' fields.
    Returns success or error message.
    """
    data = request.json
    
    if not data or 'emotion' not in data or 'title' not in data or 'artist' not in data or 'url' not in data:
        return jsonify({'error': 'Missing required fields'}), 400
    
    try:
        song_info = {
            'title': data['title'],
            'artist': data['artist'],
            'url': data['url']
        }
        
        success = playlist_generator.add_song(data['emotion'], song_info)
        
        if success:
            return jsonify({'message': 'Song added successfully'})
        else:
            return jsonify({'error': 'Song already exists'}), 400
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    # Create templates directory if it doesn't exist
    templates_dir = current_dir / 'templates'
    os.makedirs(templates_dir, exist_ok=True)
    
    # Create a basic index.html if it doesn't exist
    index_html = templates_dir / 'index.html'
    if not os.path.exists(index_html):
        with open(index_html, 'w') as f:
            f.write("""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sentiment Playlist Generator API</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        h1 {
            color: #333;
        }
        .endpoint {
            background-color: #f5f5f5;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        .method {
            font-weight: bold;
            color: #0066cc;
        }
        pre {
            background-color: #eee;
            padding: 10px;
            border-radius: 5px;
            overflow-x: auto;
        }
    </style>
</head>
<body>
    <h1>Sentiment Playlist Generator API</h1>
    <p>This API analyzes text sentiment and generates song playlists based on the detected emotion.</p>
    
    <div class="endpoint">
        <h2><span class="method">POST</span> /api/analyze</h2>
        <p>Analyze text sentiment and generate a playlist.</p>
        <h3>Request:</h3>
        <pre>
{
    "text": "I'm feeling really happy today!",
    "count": 3  // Optional, defaults to 5
}
        </pre>
        <h3>Response:</h3>
        <pre>
{
    "sentiment": {
        "category": "positive",
        "emotion": "joy",
        "scores": {
            "neg": 0.0,
            "neu": 0.333,
            "pos": 0.667,
            "compound": 0.6369
        }
    },
    "playlist": [
        {
            "title": "Happy",
            "artist": "Pharrell Williams",
            "url": "https://www.youtube.com/watch?v=ZbZSe6N_BXs"
        },
        ...
    ]
}
        </pre>
    </div>
    
    <div class="endpoint">
        <h2><span class="method">GET</span> /api/songs</h2>
        <p>Get all songs in the database.</p>
        <h3>Response:</h3>
        <pre>
{
    "joy": [
        {
            "title": "Happy",
            "artist": "Pharrell Williams",
            "url": "https://www.youtube.com/watch?v=ZbZSe6N_BXs"
        },
        ...
    ],
    ...
}
        </pre>
    </div>
    
    <div class="endpoint">
        <h2><span class="method">POST</span> /api/songs</h2>
        <p>Add a new song to the database.</p>
        <h3>Request:</h3>
        <pre>
{
    "emotion": "joy",
    "title": "Happy Song",
    "artist": "Artist Name",
    "url": "https://example.com/song"
}
        </pre>
        <h3>Response:</h3>
        <pre>
{
    "message": "Song added successfully"
}
        </pre>
    </div>
</body>
</html>
            """)
    
    # Run the Flask app
    app.run(debug=True, port=5000)
