"""
Sentiment Analyzer Module

This module provides functionality to analyze the sentiment of text input
and categorize it into different emotional categories.
"""

import re
import nltk
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords

# Download necessary NLTK resources
try:
    nltk.data.find('vader_lexicon')
    nltk.data.find('punkt')
    nltk.data.find('stopwords')
except LookupError:
    nltk.download('vader_lexicon')
    nltk.download('punkt')
    nltk.download('stopwords')

class SentimentAnalyzer:
    """Class for analyzing sentiment in text."""
    
    def __init__(self):
        """Initialize the sentiment analyzer with VADER."""
        self.analyzer = SentimentIntensityAnalyzer()
        self.stop_words = set(stopwords.words('english'))
        
    def preprocess_text(self, text):
        """
        Preprocess text by removing special characters, converting to lowercase,
        and removing stopwords.
        
        Args:
            text (str): Input text to preprocess
            
        Returns:
            str: Preprocessed text
        """
        # Convert to lowercase
        text = text.lower()
        
        # Remove special characters and numbers
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        
        # Tokenize
        tokens = word_tokenize(text)
        
        # Remove stopwords
        filtered_tokens = [word for word in tokens if word not in self.stop_words]
        
        # Join tokens back into a string
        preprocessed_text = ' '.join(filtered_tokens)
        
        return preprocessed_text
    
    def analyze(self, text):
        """
        Analyze the sentiment of the given text.
        
        Args:
            text (str): Input text to analyze
            
        Returns:
            dict: Dictionary containing sentiment scores and category
        """
        # Preprocess the text
        preprocessed_text = self.preprocess_text(text)
        
        # Get sentiment scores
        scores = self.analyzer.polarity_scores(preprocessed_text)
        
        # Determine sentiment category
        if scores['compound'] >= 0.05:
            category = 'positive'
        elif scores['compound'] <= -0.05:
            category = 'negative'
        else:
            category = 'neutral'
        
        # Determine more specific emotion
        emotion = self._determine_emotion(preprocessed_text, scores)
        
        return {
            'scores': scores,
            'category': category,
            'emotion': emotion
        }
    
    def _determine_emotion(self, text, scores):
        """
        Determine more specific emotion based on text and sentiment scores.
        
        Args:
            text (str): Preprocessed text
            scores (dict): VADER sentiment scores
            
        Returns:
            str: Specific emotion category
        """
        # Define emotion keywords
        emotion_keywords = {
            'joy': ['happy', 'joy', 'delighted', 'excited', 'thrilled', 'ecstatic', 'glad', 'pleased'],
            'love': ['love', 'adore', 'cherish', 'affection', 'fondness', 'passion', 'romantic'],
            'surprise': ['surprise', 'amazed', 'astonished', 'shocked', 'stunned', 'unexpected'],
            'anger': ['angry', 'mad', 'furious', 'outraged', 'irritated', 'annoyed', 'frustrated'],
            'sadness': ['sad', 'unhappy', 'depressed', 'gloomy', 'miserable', 'heartbroken', 'grief', 'cry'],
            'fear': ['afraid', 'scared', 'frightened', 'terrified', 'anxious', 'worried', 'nervous'],
            'calm': ['calm', 'peaceful', 'relaxed', 'serene', 'tranquil', 'content', 'quiet'],
            'energetic': ['energetic', 'lively', 'vibrant', 'dynamic', 'active', 'spirited']
        }
        
        # Count occurrences of emotion keywords
        emotion_counts = {emotion: 0 for emotion in emotion_keywords}
        
        for word in text.split():
            for emotion, keywords in emotion_keywords.items():
                if word in keywords:
                    emotion_counts[emotion] += 1
        
        # Find the emotion with the highest count
        max_count = 0
        dominant_emotion = None
        
        for emotion, count in emotion_counts.items():
            if count > max_count:
                max_count = count
                dominant_emotion = emotion
        
        # If no specific emotion is detected, use sentiment scores
        if dominant_emotion is None:
            if scores['compound'] >= 0.5:
                dominant_emotion = 'joy'
            elif scores['compound'] >= 0.05:
                dominant_emotion = 'calm'
            elif scores['compound'] <= -0.5:
                dominant_emotion = 'sadness'
            elif scores['compound'] <= -0.05:
                dominant_emotion = 'anger'
            else:
                dominant_emotion = 'neutral'
        
        return dominant_emotion

# Example usage
if __name__ == "__main__":
    analyzer = SentimentAnalyzer()
    sample_text = "I'm feeling really happy and excited about this new project!"
    result = analyzer.analyze(sample_text)
    print(f"Sentiment: {result['category']}")
    print(f"Emotion: {result['emotion']}")
    print(f"Scores: {result['scores']}")
