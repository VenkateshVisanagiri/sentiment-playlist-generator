"""
Playlist Generator Module

This module provides functionality to generate song playlists based on
sentiment analysis results.
"""

import json
import random
import os
from pathlib import Path

class PlaylistGenerator:
    """Class for generating playlists based on sentiment."""
    
    def __init__(self, songs_file=None):
        """
        Initialize the playlist generator.
        
        Args:
            songs_file (str, optional): Path to the JSON file containing song data.
                If None, uses the default songs database.
        """
        if songs_file is None:
            # Use default songs database
            current_dir = Path(__file__).parent
            songs_file = current_dir / 'data' / 'songs.json'
            
            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(songs_file), exist_ok=True)
            
            # Create default songs database if it doesn't exist
            if not os.path.exists(songs_file):
                self._create_default_songs_database(songs_file)
        
        with open(songs_file, 'r') as f:
            self.songs_data = json.load(f)
    
    def _create_default_songs_database(self, file_path):
        """
        Create a default songs database with sample songs for different emotions.
        
        Args:
            file_path (Path): Path to save the songs database
        """
        default_songs = {
            "joy": [
                {"title": "Happy", "artist": "Pharrell Williams", "url": "https://www.youtube.com/watch?v=ZbZSe6N_BXs"},
                {"title": "Walking on Sunshine", "artist": "Katrina and The Waves", "url": "https://www.youtube.com/watch?v=iPUmE-tne5U"},
                {"title": "Good Feeling", "artist": "Flo Rida", "url": "https://www.youtube.com/watch?v=3OnnDqH6Wj8"},
                {"title": "Can't Stop the Feeling!", "artist": "Justin Timberlake", "url": "https://www.youtube.com/watch?v=ru0K8uYEZWw"},
                {"title": "Uptown Funk", "artist": "Mark Ronson ft. Bruno Mars", "url": "https://www.youtube.com/watch?v=OPf0YbXqDm0"}
            ],
            "love": [
                {"title": "All of Me", "artist": "John Legend", "url": "https://www.youtube.com/watch?v=450p7goxZqg"},
                {"title": "Perfect", "artist": "Ed Sheeran", "url": "https://www.youtube.com/watch?v=2Vv-BfVoq4g"},
                {"title": "Just the Way You Are", "artist": "Bruno Mars", "url": "https://www.youtube.com/watch?v=LjhCEhWiKXk"},
                {"title": "Thinking Out Loud", "artist": "Ed Sheeran", "url": "https://www.youtube.com/watch?v=lp-EO5I60KA"},
                {"title": "Love On Top", "artist": "Beyoncé", "url": "https://www.youtube.com/watch?v=Ob7vObnFUJc"}
            ],
            "surprise": [
                {"title": "Wow", "artist": "Post Malone", "url": "https://www.youtube.com/watch?v=393C3pr2ioY"},
                {"title": "Firework", "artist": "Katy Perry", "url": "https://www.youtube.com/watch?v=QGJuMBdaqIw"},
                {"title": "Dynamite", "artist": "BTS", "url": "https://www.youtube.com/watch?v=gdZLi9oWNZg"},
                {"title": "Starboy", "artist": "The Weeknd ft. Daft Punk", "url": "https://www.youtube.com/watch?v=34Na4j8AVgA"},
                {"title": "Blinding Lights", "artist": "The Weeknd", "url": "https://www.youtube.com/watch?v=4NRXx6U8ABQ"}
            ],
            "anger": [
                {"title": "Till I Collapse", "artist": "Eminem", "url": "https://www.youtube.com/watch?v=ytQ5CYE1VZw"},
                {"title": "Numb", "artist": "Linkin Park", "url": "https://www.youtube.com/watch?v=kXYiU_JCYtU"},
                {"title": "Break Stuff", "artist": "Limp Bizkit", "url": "https://www.youtube.com/watch?v=ZpUYjpKg9KY"},
                {"title": "Killing In The Name", "artist": "Rage Against The Machine", "url": "https://www.youtube.com/watch?v=bWXazVhlyxQ"},
                {"title": "Bodies", "artist": "Drowning Pool", "url": "https://www.youtube.com/watch?v=04F4xlWSFh0"}
            ],
            "sadness": [
                {"title": "Someone Like You", "artist": "Adele", "url": "https://www.youtube.com/watch?v=hLQl3WQQoQ0"},
                {"title": "Fix You", "artist": "Coldplay", "url": "https://www.youtube.com/watch?v=k4V3Mo61fJM"},
                {"title": "Hurt", "artist": "Johnny Cash", "url": "https://www.youtube.com/watch?v=8AHCfZTRGiI"},
                {"title": "Say Something", "artist": "A Great Big World ft. Christina Aguilera", "url": "https://www.youtube.com/watch?v=-2U0Ivkn2Ds"},
                {"title": "When I Was Your Man", "artist": "Bruno Mars", "url": "https://www.youtube.com/watch?v=ekzHIouo8Q4"}
            ],
            "fear": [
                {"title": "Thriller", "artist": "Michael Jackson", "url": "https://www.youtube.com/watch?v=sOnqjkJTMaA"},
                {"title": "Enter Sandman", "artist": "Metallica", "url": "https://www.youtube.com/watch?v=CD-E-LDc384"},
                {"title": "Disturbia", "artist": "Rihanna", "url": "https://www.youtube.com/watch?v=E1mU6h4Xdxc"},
                {"title": "Sweet Dreams", "artist": "Marilyn Manson", "url": "https://www.youtube.com/watch?v=QUvVdTlA23w"},
                {"title": "Psycho Killer", "artist": "Talking Heads", "url": "https://www.youtube.com/watch?v=O52jAYa4Pm8"}
            ],
            "calm": [
                {"title": "Weightless", "artist": "Marconi Union", "url": "https://www.youtube.com/watch?v=UfcAVejslrU"},
                {"title": "Breathe Me", "artist": "Sia", "url": "https://www.youtube.com/watch?v=ghPcYqn0p4Y"},
                {"title": "Chasing Cars", "artist": "Snow Patrol", "url": "https://www.youtube.com/watch?v=GemKqzILV4w"},
                {"title": "Skinny Love", "artist": "Bon Iver", "url": "https://www.youtube.com/watch?v=ssdgFoHLwnk"},
                {"title": "The Scientist", "artist": "Coldplay", "url": "https://www.youtube.com/watch?v=RB-RcX5DS5A"}
            ],
            "energetic": [
                {"title": "Can't Hold Us", "artist": "Macklemore & Ryan Lewis", "url": "https://www.youtube.com/watch?v=2zNSgSzhBfM"},
                {"title": "Levels", "artist": "Avicii", "url": "https://www.youtube.com/watch?v=_ovdm2yX4MA"},
                {"title": "Don't Stop Me Now", "artist": "Queen", "url": "https://www.youtube.com/watch?v=HgzGwKwLmgM"},
                {"title": "Wake Me Up", "artist": "Avicii", "url": "https://www.youtube.com/watch?v=IcrbM1l_BoI"},
                {"title": "Stronger", "artist": "Kanye West", "url": "https://www.youtube.com/watch?v=PsO6ZnUZI0g"}
            ],
            "neutral": [
                {"title": "Clocks", "artist": "Coldplay", "url": "https://www.youtube.com/watch?v=d020hcWA_Wg"},
                {"title": "Viva La Vida", "artist": "Coldplay", "url": "https://www.youtube.com/watch?v=dvgZkm1xWPE"},
                {"title": "Counting Stars", "artist": "OneRepublic", "url": "https://www.youtube.com/watch?v=hT_nvWreIhg"},
                {"title": "Believer", "artist": "Imagine Dragons", "url": "https://www.youtube.com/watch?v=7wtfhZwyrcc"},
                {"title": "Radioactive", "artist": "Imagine Dragons", "url": "https://www.youtube.com/watch?v=ktvTqknDobU"}
            ]
        }
        
        with open(file_path, 'w') as f:
            json.dump(default_songs, f, indent=4)
        
        self.songs_data = default_songs
    
    def generate_playlist(self, emotion, count=5):
        """
        Generate a playlist based on the detected emotion.
        
        Args:
            emotion (str): The detected emotion from sentiment analysis
            count (int, optional): Number of songs to include in the playlist. Defaults to 5.
            
        Returns:
            list: A list of song dictionaries for the playlist
        """
        # If the emotion is not in our database, use neutral
        if emotion not in self.songs_data:
            emotion = 'neutral'
        
        # Get all songs for the emotion
        emotion_songs = self.songs_data[emotion]
        
        # If we have fewer songs than requested, return all available songs
        if len(emotion_songs) <= count:
            return emotion_songs
        
        # Otherwise, randomly select the requested number of songs
        return random.sample(emotion_songs, count)
    
    def add_song(self, emotion, song_info):
        """
        Add a new song to the database.
        
        Args:
            emotion (str): The emotion category for the song
            song_info (dict): Dictionary containing song information (title, artist, url)
            
        Returns:
            bool: True if the song was added successfully, False otherwise
        """
        # Create the emotion category if it doesn't exist
        if emotion not in self.songs_data:
            self.songs_data[emotion] = []
        
        # Check if the song already exists
        for song in self.songs_data[emotion]:
            if song['title'] == song_info['title'] and song['artist'] == song_info['artist']:
                return False
        
        # Add the song
        self.songs_data[emotion].append(song_info)
        
        # Save the updated database
        current_dir = Path(__file__).parent
        songs_file = current_dir / 'data' / 'songs.json'
        
        with open(songs_file, 'w') as f:
            json.dump(self.songs_data, f, indent=4)
        
        return True

# Example usage
if __name__ == "__main__":
    generator = PlaylistGenerator()
    playlist = generator.generate_playlist('joy', 3)
    print("Joy Playlist:")
    for song in playlist:
        print(f"{song['title']} by {song['artist']}")
