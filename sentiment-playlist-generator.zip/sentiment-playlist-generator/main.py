"""
Sentiment Playlist Generator

Main entry point for the application.
"""

import os
import sys
import webbrowser
from pathlib import Path
import threading
import time

# Add the src directory to the Python path
current_dir = Path(__file__).parent
src_dir = current_dir / 'src'
if str(src_dir) not in sys.path:
    sys.path.append(str(src_dir))

# Import the Flask app
from src.backend.app import app

def open_browser():
    """Open the browser after a short delay to ensure the server is running."""
    time.sleep(1.5)
    webbrowser.open('http://localhost:5000')

if __name__ == '__main__':
    # Create the data directory if it doesn't exist
    data_dir = current_dir / 'src' / 'backend' / 'data'
    os.makedirs(data_dir, exist_ok=True)
    
    # Print startup message
    print("=" * 70)
    print("Sentiment Playlist Generator")
    print("=" * 70)
    print("Starting server...")
    print("Once the server is running, you can access the application at:")
    print("http://localhost:5000")
    print("\nPress Ctrl+C to stop the server.")
    print("=" * 70)
    
    # Open browser automatically
    threading.Thread(target=open_browser).start()
    
    # Start the Flask app
    app.run(debug=True, port=5000)
