"""
Run script for the Sentiment Playlist Generator.

This script provides a simple way to start the application with various options.
"""

import os
import sys
import argparse
import webbrowser
import threading
import time
from pathlib import Path

# Add the src directory to the Python path
current_dir = Path(__file__).parent
src_dir = current_dir / 'src'
if str(src_dir) not in sys.path:
    sys.path.append(str(src_dir))

def check_dependencies():
    """Check if all required dependencies are installed."""
    try:
        import flask
        import flask_cors
        import nltk
        
        # Check for NLTK resources
        try:
            nltk.data.find('vader_lexicon')
            nltk.data.find('punkt')
            nltk.data.find('stopwords')
        except LookupError:
            print("Downloading required NLTK resources...")
            nltk.download('vader_lexicon')
            nltk.download('punkt')
            nltk.download('stopwords')
            print("NLTK resources downloaded successfully.")
        
        return True
    
    except ImportError as e:
        print(f"Error: Missing dependency - {e}")
        print("Please install all required dependencies using:")
        print("pip install -r requirements.txt")
        return False

def open_browser(port):
    """Open the browser after a short delay to ensure the server is running."""
    time.sleep(1.5)
    webbrowser.open(f'http://localhost:{port}')

def run_app(port=5000, debug=False, open_browser_flag=True):
    """Run the Flask application."""
    from src.backend.app import app
    
    # Create the data directory if it doesn't exist
    data_dir = current_dir / 'src' / 'backend' / 'data'
    os.makedirs(data_dir, exist_ok=True)
    
    # Print startup message
    print("=" * 70)
    print("Sentiment Playlist Generator")
    print("=" * 70)
    print(f"Starting server on port {port}...")
    print("Once the server is running, you can access the application at:")
    print(f"http://localhost:{port}")
    print("\nPress Ctrl+C to stop the server.")
    print("=" * 70)
    
    # Open browser automatically if flag is set
    if open_browser_flag:
        threading.Thread(target=open_browser, args=(port,)).start()
    
    # Start the Flask app
    app.run(debug=debug, port=port)

def run_test():
    """Run the test script."""
    import subprocess
    subprocess.run([sys.executable, 'test_sentiment.py'])

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Run the Sentiment Playlist Generator.')
    parser.add_argument('--port', type=int, default=5000, help='Port to run the server on (default: 5000)')
    parser.add_argument('--debug', action='store_true', help='Run the server in debug mode')
    parser.add_argument('--no-browser', action='store_true', help='Do not open the browser automatically')
    parser.add_argument('--test', action='store_true', help='Run the test script instead of the web application')
    
    args = parser.parse_args()
    
    # Check dependencies
    if not check_dependencies():
        sys.exit(1)
    
    if args.test:
        run_test()
    else:
        run_app(port=args.port, debug=args.debug, open_browser_flag=not args.no_browser)
