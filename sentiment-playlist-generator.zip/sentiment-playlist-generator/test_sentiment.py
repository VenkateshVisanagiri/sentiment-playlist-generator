"""
Test script for the Sentiment Analyzer and Playlist Generator.

This script allows you to test the core functionality of the sentiment analyzer
and playlist generator without running the full web application.
"""

import sys
from pathlib import Path

# Add the src directory to the Python path
current_dir = Path(__file__).parent
src_dir = current_dir / 'src'
if str(src_dir) not in sys.path:
    sys.path.append(str(src_dir))

from src.backend.sentiment_analyzer import SentimentAnalyzer
from src.backend.playlist_generator import PlaylistGenerator

def test_sentiment_analyzer():
    """Test the sentiment analyzer with various inputs."""
    analyzer = SentimentAnalyzer()
    
    test_texts = [
        "I'm feeling really happy and excited today!",
        "I'm so angry and frustrated with everything right now.",
        "I feel sad and depressed, nothing seems to be going right.",
        "I'm a bit anxious about the upcoming presentation.",
        "I feel calm and peaceful after my meditation session.",
        "I'm in love and everything is wonderful!",
        "I'm surprised by the unexpected turn of events.",
        "I'm feeling very energetic and ready to take on the world!"
    ]
    
    print("\n" + "=" * 70)
    print("SENTIMENT ANALYZER TEST")
    print("=" * 70)
    
    for text in test_texts:
        result = analyzer.analyze(text)
        print(f"\nText: \"{text}\"")
        print(f"Sentiment: {result['category']}")
        print(f"Emotion: {result['emotion']}")
        print(f"Compound Score: {result['scores']['compound']:.2f}")
        print("-" * 70)

def test_playlist_generator():
    """Test the playlist generator for different emotions."""
    generator = PlaylistGenerator()
    
    emotions = [
        "joy", "anger", "sadness", "fear", 
        "calm", "love", "surprise", "energetic"
    ]
    
    print("\n" + "=" * 70)
    print("PLAYLIST GENERATOR TEST")
    print("=" * 70)
    
    for emotion in emotions:
        playlist = generator.generate_playlist(emotion, 3)
        print(f"\nEmotion: {emotion}")
        
        if playlist:
            for i, song in enumerate(playlist, 1):
                print(f"{i}. \"{song['title']}\" by {song['artist']}")
        else:
            print("No songs found for this emotion.")
        
        print("-" * 70)

def interactive_test():
    """Run an interactive test where the user can input text."""
    analyzer = SentimentAnalyzer()
    generator = PlaylistGenerator()
    
    print("\n" + "=" * 70)
    print("INTERACTIVE SENTIMENT PLAYLIST GENERATOR TEST")
    print("=" * 70)
    print("Enter your text to analyze the sentiment and generate a playlist.")
    print("Type 'exit' to quit.")
    print("=" * 70)
    
    while True:
        text = input("\nEnter your text: ")
        
        if text.lower() == 'exit':
            break
        
        if not text.strip():
            print("Please enter some text to analyze.")
            continue
        
        # Analyze sentiment
        result = analyzer.analyze(text)
        
        print("\nSENTIMENT ANALYSIS RESULTS:")
        print(f"Sentiment: {result['category']}")
        print(f"Emotion: {result['emotion']}")
        print(f"Compound Score: {result['scores']['compound']:.2f}")
        
        # Generate playlist
        playlist = generator.generate_playlist(result['emotion'], 3)
        
        print("\nYOUR PERSONALIZED PLAYLIST:")
        if playlist:
            for i, song in enumerate(playlist, 1):
                print(f"{i}. \"{song['title']}\" by {song['artist']}")
                print(f"   Listen: {song['url']}")
        else:
            print("No songs found for this emotion.")
        
        print("-" * 70)

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Test the Sentiment Analyzer and Playlist Generator.')
    parser.add_argument('--analyzer', action='store_true', help='Test the sentiment analyzer with predefined texts')
    parser.add_argument('--playlist', action='store_true', help='Test the playlist generator with different emotions')
    parser.add_argument('--interactive', action='store_true', help='Run an interactive test')
    
    args = parser.parse_args()
    
    if args.analyzer:
        test_sentiment_analyzer()
    
    if args.playlist:
        test_playlist_generator()
    
    if args.interactive or not (args.analyzer or args.playlist):
        interactive_test()
